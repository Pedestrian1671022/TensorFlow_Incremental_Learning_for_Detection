% clc - clear command window.
%
% USAGE
%  c
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also CLC, CC, CCC
%
% Piotr's Computer Vision Matlab Toolbox      Version 1.5
% Copyright 2014 Piotr Dollar.  [pdollar-at-gmail.com]
% Licensed under the Simplified BSD License [see external/bsd.txt]

clc
